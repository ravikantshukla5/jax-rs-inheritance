package com.socgen.utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.socgen.model.WebserviceModel;

public class ServiceUtils {
	
	public static WebserviceModel getServiceDeatailsBasedOnName(String wsName){
		Connection con = DbUtils.getConnection();
		WebserviceModel wsModel = null;
	    try {
			Statement stm =  con.createStatement();
			String sql = "select * from WS_DETAILS where WS_METHOD = '"+wsName+"'";
			ResultSet rs = stm.executeQuery(sql);
			while(rs.next()){
				Integer serviceId = rs.getInt("WS_ID");
				String serviceName = rs.getString("WS_NAME");
				String serviceMethod = rs.getString("WS_METHOD");
				String serviceParameters = rs.getString("WS_PARAMETERS");
				String serviceMainQuery = rs.getString("WS_MAIN_QUERY");
				String serviceOptionalQuery = rs.getString("WS_OPTIONAL_QUERY");
				List<String> parameters = new ArrayList<String>();
				if(serviceParameters != null){
					parameters = Arrays.asList(serviceParameters.split(","));
				}
                
                wsModel = new WebserviceModel(serviceId,serviceName,serviceMethod,parameters,serviceMainQuery,serviceOptionalQuery);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	    return wsModel;
	}
	public static Map<String,WebserviceModel> getWebserviceInfo() {
		Connection con = DbUtils.getConnection();
		Map<String,WebserviceModel> wsInfos = new LinkedHashMap<String,WebserviceModel>();
	    try {
			Statement stm =  con.createStatement();
			String sql = "select * from WS_DETAILS";
			ResultSet rs = stm.executeQuery(sql);
			while(rs.next()){
				Integer serviceId = rs.getInt("WS_ID");
				String serviceName = rs.getString("WS_NAME");
				String serviceMethod = rs.getString("WS_METHOD");
				String serviceParameters = rs.getString("WS_PARAMETERS");
				String serviceMainQuery = rs.getString("WS_MAIN_QUERY");
				String serviceOptionalQuery = rs.getString("WS_OPTIONAL_QUERY");
				List<String> parameters = new ArrayList<String>();
				if(serviceParameters != null){
					parameters = Arrays.asList(serviceParameters.split(","));
				}
                
                WebserviceModel wsModel = new WebserviceModel(serviceId,serviceName,serviceMethod,parameters,serviceMainQuery,serviceOptionalQuery);
                wsInfos.put(serviceName+"/"+serviceMethod,wsModel);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	    return wsInfos;
	}

}
