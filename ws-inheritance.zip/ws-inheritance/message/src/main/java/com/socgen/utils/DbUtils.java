package com.socgen.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class DbUtils {
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "great123");
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return con;
	}

	public static List<Map<String, Object>> getDataUsingSelect(String serviceMainQuery, String serviceOptionalQuery,
			List<String> serviceParameters) {
		//Map<String, String> data = new LinkedHashMap<String, String>();
		List<Map<String,Object>> listMap = new ArrayList<Map<String,Object>>();
		String sql = "";
		try {
			if (serviceParameters.isEmpty()) {
				sql = serviceMainQuery;
				Statement stm = getConnection().createStatement();
				ResultSet rs = stm.executeQuery(sql);
				int columnCount = rs.getMetaData().getColumnCount();
				while (rs.next()) {
					Map<String, Object> row = new LinkedHashMap<String, Object>();
					for (int count = 1; count <= columnCount; count++) {
						row.put(rs.getMetaData().getColumnName(count),
								rs.getObject(rs.getMetaData().getColumnName(count)));
					}
					listMap.add(row);
				}

			}
			if (!serviceParameters.isEmpty()) {
				if(serviceOptionalQuery != null)
				   sql = serviceMainQuery + " " + serviceOptionalQuery;
				else
				   sql = serviceMainQuery;
				PreparedStatement pstm = getConnection().prepareStatement(sql);
				int paramPosition = 1;
				for (String param : serviceParameters) {
					pstm.setString(paramPosition, param);
					paramPosition++;
				}
				ResultSet rs = pstm.executeQuery();
				int columnCount = rs.getMetaData().getColumnCount();
				while (rs.next()) {
					Map<String, Object> row = new LinkedHashMap<String, Object>();
					for (int count = 1; count <= columnCount; count++) {
						row.put(rs.getMetaData().getColumnName(count),
								rs.getObject(rs.getMetaData().getColumnName(count)));
					}
					listMap.add(row);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return listMap;
	}

}
