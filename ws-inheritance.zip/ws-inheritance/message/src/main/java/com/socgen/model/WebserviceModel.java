package com.socgen.model;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
public class WebserviceModel implements Serializable {

	private static final long serialVersionUID = -6838568850033400604L;
	private Integer serviceId;
	private String serviceName;
	private String serviceMethod;
	private List<String> serviceParameters;
	private String serviceMainQuery;
	private String serviceOptionalQuery;
	private String serviceUrl;
	public WebserviceModel(){
		
	}
	public WebserviceModel(Integer serviceId, String serviceName, String serviceMethod, List<String> serviceParameters,
			String serviceMainQuery, String serviceOptionalQuery) {
		super();
		this.serviceId = serviceId;
		this.serviceName = serviceName;
		this.serviceMethod = serviceMethod;
		this.serviceParameters = serviceParameters;
		this.serviceMainQuery = serviceMainQuery;
		this.serviceOptionalQuery = serviceOptionalQuery;
	}
	public Integer getServiceId() {
		return serviceId;
	}
	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getServiceMethod() {
		return serviceMethod;
	}
	public void setServiceMethod(String serviceMethod) {
		this.serviceMethod = serviceMethod;
	}
	public List<String> getServiceParameters() {
		return serviceParameters;
	}
	public void setServiceParameters(List<String> serviceParameters) {
		this.serviceParameters = serviceParameters;
	}
	public String getServiceMainQuery() {
		return serviceMainQuery;
	}
	public void setServiceMainQuery(String serviceMainQuery) {
		this.serviceMainQuery = serviceMainQuery;
	}
	public String getServiceOptionalQuery() {
		return serviceOptionalQuery;
	}
	public void setServiceOptionalQuery(String serviceOptionalQuery) {
		this.serviceOptionalQuery = serviceOptionalQuery;
	}
	public String getServiceUrl() {
		serviceUrl = "/"+this.getServiceMethod()+constructParameters(this.serviceParameters);
		return serviceUrl;
	}
	private String constructParameters(List<String> serviceUrls) {
		String wsParams = "/";
		for(String param : serviceUrls){
			wsParams += "{"+param+"}/";
		}
		if(!wsParams.isEmpty())
		    wsParams = wsParams.substring(0, wsParams.length()-1);
		if(wsParams.equals("/"))
			wsParams = "";
		return wsParams;
	}
	public void setServiceUrl(String serviceUrl) {
		this.serviceUrl = serviceUrl;
	}
	@Override
	public String toString() {
		return "WebserviceModel [serviceId=" + serviceId + ", serviceName=" + serviceName + ", serviceMethod="
				+ serviceMethod + ", serviceParameters=" + serviceParameters + ", serviceMainQuery=" + serviceMainQuery
				+ ", serviceOptionalQuery=" + serviceOptionalQuery + ", serviceUrl=" + serviceUrl + "]";
	}
	

}
