package com.socgen.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Application Lifecycle Listener implementation class RestContexListener
 *
 */
public class RestContexListener implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public RestContexListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent servletCotextEvent)  { 
    	System.out.println("Application context initialized");
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent servletCotextEvent)  { 
    	System.out.println("Application context initialized");
    	//servletCotextEvent.getServletContext().setAttribute("webserviceInfo",getWebserviceInfo());
    }
	
}
