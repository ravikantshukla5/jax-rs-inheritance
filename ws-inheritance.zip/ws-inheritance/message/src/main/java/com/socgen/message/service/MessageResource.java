package com.socgen.message.service;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.socgen.model.WebserviceModel;
import com.socgen.utils.DbUtils;
import com.socgen.utils.ServiceUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Path("/messageResource")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Api(value = "This base service for message requests", description = "This base service for message requests")
public class MessageResource {

	@Path("/getMessages")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "This is operation will resturn all messages")
	public List<Map<String, Object>> getMessages() {
		WebserviceModel wsModel = ServiceUtils.getServiceDeatailsBasedOnName("getMessages");
		List<Map<String, Object>> jsonRes = DbUtils.getDataUsingSelect(wsModel.getServiceMainQuery(),
				wsModel.getServiceOptionalQuery(), wsModel.getServiceParameters());
		return jsonRes;
	}

	@Path("/getMessages/{id}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "This is operation will resturn messages for given id")
	public List<Map<String, Object>> getMessage(@PathParam("id") String id) {
		WebserviceModel wsModel = ServiceUtils.getServiceDeatailsBasedOnName("getMessage");
		List<Map<String, Object>> jsonRes = DbUtils.getDataUsingSelect(wsModel.getServiceMainQuery(),
				wsModel.getServiceOptionalQuery(), Arrays.asList(id));
		return jsonRes;
	}

	@Path("/getMessage/{messageId}/getComments")
	@ApiOperation(value = "This is operation will resturn all comments for given message")
	public CommentResource getComments() {
		return new CommentResource();
	}
	@GET
	@Path("/getAvailableServices")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "This service will provides information about available services")
	public Map<String, WebserviceModel> getAvailableServices(@Context ServletContext context) {
		//Map<String, WebserviceModel> wsInfos = (Map<String, WebserviceModel>) context.getAttribute("webserviceInfo");
		Map<String, WebserviceModel> wsInfos = ServiceUtils.getWebserviceInfo();
		return wsInfos;
	}
	/*
	 * public List<WebserviceModel> getURI(){ Connection con =
	 * DbUtils.getConnection(); List<WebserviceModel> wsInfos = new
	 * ArrayList<WebserviceModel>(); try { Statement stm =
	 * con.createStatement(); String sql = "select * from WS_DETAILS"; ResultSet
	 * rs = stm.executeQuery(sql); while(rs.next()){ Integer serviceId =
	 * rs.getInt("WS_ID"); String serviceName = rs.getString("WS_NAME"); String
	 * serviceMethod = rs.getString("WS_METHOD"); String serviceParameters =
	 * rs.getString("WS_PARAMETERS"); String serviceMainQuery =
	 * rs.getString("WS_MAIN_QUERY"); String serviceOptionalQuery =
	 * rs.getString("WS_OPTIONAL_QUERY"); List<String> parameters = new
	 * ArrayList<String>(); if(serviceParameters != null){ parameters =
	 * Arrays.asList(serviceParameters.split(",")); }
	 * 
	 * WebserviceModel wsModel = new
	 * WebserviceModel(serviceId,serviceName,serviceMethod,parameters,
	 * serviceMainQuery,serviceOptionalQuery); wsInfos.add(wsModel); } } catch
	 * (SQLException e) { e.printStackTrace(); } return wsInfos; }
	 */

}
