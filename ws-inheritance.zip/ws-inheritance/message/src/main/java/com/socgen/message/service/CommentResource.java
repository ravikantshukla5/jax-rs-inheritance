package com.socgen.message.service;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.socgen.model.WebserviceModel;
import com.socgen.utils.DbUtils;
import com.socgen.utils.ServiceUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * Root resource (exposed at "myresource" path)
 */
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Api(value="Comment Resource",description="Comment resource this is sub resource for Message resource")
public class CommentResource{

    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @return String that will be returned as a text/plain response.
     */
    @GET
    @ApiOperation(value = "View the comments of specific messages")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Map<String, Object>> getComments(@PathParam("messageId") String messageId) {
    	WebserviceModel wsModel = ServiceUtils.getServiceDeatailsBasedOnName("getComments");
		List<Map<String, Object>> jsonRes = DbUtils.getDataUsingSelect(wsModel.getServiceMainQuery(),
				wsModel.getServiceOptionalQuery(), Arrays.asList(messageId));
        return jsonRes;
    }
    @GET
    @ApiOperation(value = "View the comment of specific messages and specific comment")
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/{commentId}")
    public List<Map<String, Object>> getComment(@PathParam("messageId") String messageId,@PathParam("commentId") String commentId) {
    	WebserviceModel wsModel = ServiceUtils.getServiceDeatailsBasedOnName("getComment");
		List<Map<String, Object>> jsonRes = DbUtils.getDataUsingSelect(wsModel.getServiceMainQuery(),
				wsModel.getServiceOptionalQuery(), Arrays.asList(messageId,commentId));
        return jsonRes;
    }
}
