SwaggerUI uses [SwaggerJS](https://github.com/swagger-api/swagger-js) library for many internal operations. If you see errors in swagger-client.js code, you should probably open the issue in [SwaggerJS](https://github.com/swagger-api/swagger-js) repository.

Please open issues related to OpenAPI Specifications in [OpenAPI Specs](https://github.com/OAI/OpenAPI-Specification) repository.
