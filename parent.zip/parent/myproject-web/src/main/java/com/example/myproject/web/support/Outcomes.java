package com.example.myproject.web.support;

public class Outcomes {
    
    public static final String INPUT = "input";
    public static final String SUCCESS = "success";
    public static final String ERROR = "error";
    public static final String SAME = null;

    private Outcomes() {
    }
    
}
