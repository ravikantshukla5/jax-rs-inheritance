package com.example.myproject.persistence;

import com.example.myproject.persistence.test.BaseIT;
import org.junit.Test;

public class DBUnitIT extends BaseIT {
    
    @Test
    public void test() {
        // do nothing. only to test DBUnit setup is correctly
    }
    
}
