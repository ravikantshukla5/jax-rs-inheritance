package com.example.myproject.business.example;

public class ExampleNotFoundException extends Exception {

    ExampleNotFoundException(final String message) {
        super(message);
    }
    
}
